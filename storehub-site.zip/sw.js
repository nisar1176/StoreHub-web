/* StoreHub service worker: opens instantly from cache (works offline), refreshes itself in the background */
const V='mr-v57',CORE=['./','./index.html','./manifest.json'],SHELL=CORE.concat(['./zxing.min.js','./icon-192.png','./icon-512.png','./icon-maskable-192.png','./icon-maskable-512.png']),
 EXTRA=['https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap'];
self.addEventListener('install',e=>{e.waitUntil((async()=>{const c=await caches.open(V);await Promise.all(CORE.map(u=>c.add(new Request(u,{cache:'reload'})))); /* only the core files must succeed: a weak connection can no longer cancel the install */
 await Promise.all(SHELL.filter(u=>!CORE.includes(u)).map(u=>c.add(new Request(u,{cache:'reload'})).catch(()=>{})));
 await Promise.all(EXTRA.map(u=>fetch(u,{mode:'cors',credentials:'omit'}).then(r=>{if(r.ok)return c.put(u,r)}).catch(()=>{}))); /* real CORS responses only: never cache an opaque (possibly error) reply */self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V&&x!=='mr-share').map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const q=e.request;
 if(q.method==='POST'&&new URL(q.url).pathname.endsWith('/share-target')){ /* files shared from WhatsApp etc. */
  e.respondWith((async()=>{try{const fd=await q.formData(),c=await caches.open('mr-share');let i=0;
   for(const f of fd.getAll('files')){if(f&&f.size&&f.size<60e6)await c.put('./shared/'+(i++),new Response(f,{headers:{'X-Name':encodeURIComponent(f.name||'')}}))}
   const t=[fd.get('text'),fd.get('title')].filter(Boolean).join('\n');if(t&&t.includes('"mr"'))await c.put('./shared/'+(i++),new Response(t))}catch(_){}
   return Response.redirect(new URL('./index.html?shared=1',self.registration.scope).href,303)})());return}
 if(q.method!=='GET'||!/^https?:/.test(q.url)||new URL(q.url).searchParams.has('chk'))return; /* version checks always go to the network */
 e.respondWith((async()=>{const c=await caches.open(V),hit=await c.match(q,{ignoreSearch:q.mode==='navigate'});
  const x=new URL(q.url).origin!==self.location.origin,go=x?fetch(q.url,{mode:'cors',credentials:'omit'}).catch(()=>fetch(q)):fetch(q),
   net=go.then(r=>{if(r&&r.status===200&&r.type!=='opaque')c.put(q,r.clone()).catch(()=>{});return r}).catch(()=>null);
  if(hit){e.waitUntil(net);return hit}
  const r=await net;return r||(q.mode==='navigate'?await c.match('./index.html'):Response.error())})())});
self.addEventListener('message',e=>{if(e.data!=='refresh')return;const src=e.source;e.waitUntil((async()=>{try{const c=await caches.open(V);await Promise.all(CORE.map(u=>c.add(new Request(u,{cache:'reload'}))));await Promise.all(SHELL.filter(u=>!CORE.includes(u)).map(u=>c.add(new Request(u,{cache:'reload'})).catch(()=>{})))}catch(_){}try{src&&src.postMessage('refreshed')}catch(_){}})())});
